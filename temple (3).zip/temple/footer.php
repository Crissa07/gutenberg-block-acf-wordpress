<footer class="footer">
	<div class="footer-top">
		<div class="footer-logo">
			<a href="<?php echo get_home_url(); ?>">
				<img  class="img-fluid" src="<?php the_field('footer_logo', 'option'); ?>">
			</a>
		</div>
		<div class="footer-contact">
			<div class="footer-unless">
				<strong><?php the_field('button_above_first_text', 'option'); ?> <span><?php the_field('button_above_second_text', 'option'); ?></span></strong>
				<a href="<?php the_field('footer_button_link', 'option'); ?>"><?php the_field('footer_button_text', 'option'); ?></a>
				<span class="ft-unless-text"><?php the_field('button_above_second_text', 'option'); ?></span>
			</div>
			<div class="footer-social">
				<ul>
					<?php while(has_sub_field('social_media', 'option')): ?>
					<li>
						<a href="<?php the_sub_field('social_icon_link', 'option'); ?>">
							
							<img src="<?php the_sub_field('social_icon', 'option'); ?>" alt="facebook" width="20" height="19" >
						</a>
					</li>
					<?php endwhile; ?>
				</ul>
			</div>
		</div>
	</div>
	<div class="footer-consultation">
		<h2><?php the_field('form_section_title', 'option'); ?></h2>
		<div class="form">
			<?php echo do_shortcode( '[contact-form-7 id="5cfc75b" title="footer"]' ); ?> 
			<div class="form-text-bar">
				<p>*We're committed to your privacy. You may unsubscribe at any time. For more information, check out our Privacy Policy.</p>
			</div>
		</div>
	</div>
</footer>
<div class="footer-twobox">
	<div class="footer-two">
		<?php the_field('map_iframe', 'option'); ?>
	</div>
	<div class="get-direction">
		<h2><?php the_field('footer_company_name', 'option'); ?></h2>
		<p><?php the_field('address', 'option'); ?></p>
		<a href="<?php the_field('footer_button_link', 'option'); ?>"><span>T:</span> <?php the_field('footer_button_text', 'option'); ?></a>
		<div class="direction-bar">
			<a href="<?php the_field('get_directions_link', 'option'); ?>"><?php the_field('get_directions_text', 'option'); ?></a>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="footer-helpful">
		<strong>HELPFUL LINKS:</strong>
		<ul>
			<?php
			// Display custom menu
				wp_nav_menu(array(
				    'theme_location' => 'main-menu',
				    'container' => false,
				    'items_wrap' => '%3$s', // Remove the <ul> container
				    'link_before' => '<a class="nav-link" href="#">', // Add classes to the <a> tags
				    'link_after' => '</a>',
				));
			?>
		</ul>
	</div>
	<div class="footer-bottom-bar">
		<p><?php the_field('copy_write_text', 'option'); ?> <?php while(has_sub_field('footer_quick_link', 'option')): ?> <a href="<?php the_sub_field('quick_menu_link', 'option'); ?>"><?php the_sub_field('quick_menu_text', 'option'	); ?>|</a> <?php endwhile; ?><!-- <a href="#">Site Map |</a> <a href="#">Privacy Policy |</a> <a href="#">Disclaimer</a> --></p>
		<p>
			<img src="<?php the_field('website_create_by_logo', 'option'); ?>"> Site by <a href="<?php the_field('website_create_by_text_link', 'option'); ?>"><?php the_field('website_create_by_text', 'option'); ?></a> 
		</p>
	</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="js/custom.js"></script>
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
	<?php wp_footer(); ?>
</body>
</html>