<section class="hero_banner">
	<div class="hero_banner_box">
		<div class="row">
			<div class="col-lg-7">
				<div class="hero_banner_content">
					<h1><?php the_field('hero_banner_title'); ?></h1>
					<h3><?php the_field('hero_banner_subtitle'); ?></h3>
					<p><?php the_field('hero_banner_description'); ?></p>
					<a href="<?php the_field('button_number');?>"><?php the_field('hero_banner_button_text'); ?></a>
				</div>
			</div>
			<div class="col-lg-5">
				<div class="hero_banner_content_img" style="background-image: url('<?php the_field('hero_bg_image'); ?>');">
					<img src="<?php the_field('hero_banner_image'); ?>">
					<div class="hero_banner_client_name">
						<h2><?php the_field('hero_banner_client_name'); ?></h2>
						<span><?php the_field('hero_banner_client_title'); ?></span>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
