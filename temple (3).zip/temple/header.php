<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Temple
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
<link rel="stylesheet" type="text/css" href="assets/css/style.css" />

	<!-- Bootstrap cdn link -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'temple' ); ?></a>

<header class="header_sec">
    <nav class="navbar navbar-expand-lg">
        <div class="header_box_in">
            <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <img src="<?php the_field('header_logo', 'option'); ?>" alt="logo" class="img-fluid">
            </a>
            <div class="header_bar_in">
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary-menu',
                            'menu_class' => 'navbar-nav mb-2 mb-lg-0 ms-auto',
                            'container' => false
                        ));
                    ?>
                </div>
                <div class="header_contact_bar">
                    <span><?php the_field('number_label', 'option'); ?></span>
                    <a href="tel:<?php the_field('number', 'option'); ?>"><?php the_field('number', 'option'); ?></a>
                    <span class="unless_text"><?php the_field('button_sub_text', 'option'); ?></span>
                </div>
            </div>
            <div class="header_contact_mobile header_contact_bar">
                <a href="tel:<?php the_field('number', 'option'); ?>"><span><?php the_field('number_label', 'option'); ?></span> <?php the_field('number', 'option'); ?></a>
            </div>
        </div>
    </nav>
</header>
