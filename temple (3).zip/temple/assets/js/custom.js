$(document).ready(function() {
  $("body").on("click" , ".accordion-button" , function(){
    $(".faqs-bar").removeClass("active");
    if($(this).parent(".accordion-header").next(".accordion-collapse").hasClass("show")){
      $(this).parents(".faqs-bar").removeClass("active");
    } else {
      $(this).parents(".faqs-bar").addClass("active");
    }

  })
  $('.banner-slider-box').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: false,
    autoplay: true,
    autoplaySpeed: 2000,
  });
  $('.testimonials-bar').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: false,
    autoplay: true,
    autoplaySpeed: 2000,
  });
});



const progressContainer = document.querySelector('.progress-container');
const progressContainer2 = document.querySelector('.progress-container2');

// initial call
setPercentage();
setPercentage2();

function setPercentage() {
  const percentage = progressContainer.getAttribute('data-percentage') + '%';
  
  const progressEl = progressContainer.querySelector('.progress');
  const percentageEl = progressContainer.querySelector('.percentage');
  
  progressEl.style.width = percentage;
  percentageEl.innerText = percentage;
  percentageEl.style.left = percentage;
}
function setPercentage2() {
  const percentage = progressContainer2.getAttribute('data-percentage') + '%';
  
  const progressEl = progressContainer2.querySelector('.progress');
  const percentageEl = progressContainer2.querySelector('.percentage');
  
  progressEl.style.width = percentage;
  percentageEl.innerText = percentage;
  percentageEl.style.left = percentage;
}